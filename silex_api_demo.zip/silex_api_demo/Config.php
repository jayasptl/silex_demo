<?php
/**
 * Database configuration
 */
define('DB_USERNAME', 'guestbook');
define('DB_PASSWORD', '2NHRHnzYzvdr8PBJ');
define('DB_HOST', 'localhost');
define('DB_NAME', 'silex');

define('USER_CREATED_SUCCESSFULLY', 0);
define('USER_CREATE_FAILED', 1);
define('USER_ALREADY_EXISTED', 2);
?>
